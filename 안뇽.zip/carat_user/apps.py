from django.apps import AppConfig


class CaratUserConfig(AppConfig):
    name = 'carat_user'
