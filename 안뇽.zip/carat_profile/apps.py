from django.apps import AppConfig


class CaratProfileConfig(AppConfig):
    name = 'carat_profile'
