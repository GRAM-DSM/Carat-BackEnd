from django.apps import AppConfig


class CaratCaratConfig(AppConfig):
    name = 'carat_carat'
